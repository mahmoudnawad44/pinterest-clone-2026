export default defineAppConfig({
  site: {
    name: 'Pinterest Clone',
    description: 'اكتشف وألهم وحفظ الصور المفضلة لديك',
  },
  ui: {
    primary: 'red',
    gray: 'zinc',
  },
});

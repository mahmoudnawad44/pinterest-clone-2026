import { promises as fs } from 'fs';
import { resolve } from 'path';

const DB_PATH = resolve('./data/pins.json');

interface Pin {
  id: string;
  title: string;
  description?: string;
  imageUrl: string;
  externalUrl?: string;
  tags: string[];
  category?: string;
  aspectRatio?: string;
  likesCount: number;
  savesCount: number;
  createdAt: string;
}

async function ensureDb() {
  try {
    await fs.mkdir('./data', { recursive: true });
    await fs.access(DB_PATH);
  } catch {
    await fs.writeFile(DB_PATH, JSON.stringify({ pins: [] }, null, 2));
  }
}

async function readDb(): Promise<{ pins: Pin[] }> {
  await ensureDb();
  const data = await fs.readFile(DB_PATH, 'utf-8');
  return JSON.parse(data);
}

async function writeDb(db: { pins: Pin[] }) {
  await fs.writeFile(DB_PATH, JSON.stringify(db, null, 2));
}

export async function getPins(limit = 21, after?: string): Promise<{ nodes: Pin[]; pageInfo: { hasNextPage: boolean; endCursor: string | null } }> {
  const db = await readDb();
  const startIndex = after ? parseInt(after) : 0;
  const nodes = db.pins.slice(startIndex, startIndex + limit);

  return {
    nodes,
    pageInfo: {
      hasNextPage: startIndex + limit < db.pins.length,
      endCursor: String(startIndex + limit),
    },
  };
}

export async function searchPins(query: string, limit = 21): Promise<{ nodes: Pin[]; pageInfo: { hasNextPage: boolean; endCursor: null } }> {
  const db = await readDb();
  const lowerQuery = query.toLowerCase();

  const nodes = db.pins
    .filter(pin => 
      pin.title.toLowerCase().includes(lowerQuery) ||
      (pin.description && pin.description.toLowerCase().includes(lowerQuery)) ||
      pin.tags.some(tag => tag.toLowerCase().includes(lowerQuery))
    )
    .slice(0, limit);

  return {
    nodes,
    pageInfo: { hasNextPage: false, endCursor: null },
  };
}

export async function getPinsByTag(tag: string, limit = 21, after?: string): Promise<{ nodes: Pin[]; pageInfo: { hasNextPage: boolean; endCursor: string | null } }> {
  const db = await readDb();
  const startIndex = after ? parseInt(after) : 0;

  const filtered = db.pins.filter(pin => 
    pin.tags.some(t => t.toLowerCase() === tag.toLowerCase())
  );

  const nodes = filtered.slice(startIndex, startIndex + limit);

  return {
    nodes,
    pageInfo: {
      hasNextPage: startIndex + limit < filtered.length,
      endCursor: String(startIndex + limit),
    },
  };
}

export async function getPinById(id: string): Promise<Pin | null> {
  const db = await readDb();
  return db.pins.find(pin => pin.id === id) || null;
}

export async function createPin(pinData: Omit<Pin, 'id'>): Promise<Pin> {
  const db = await readDb();
  const pin: Pin = {
    ...pinData,
    id: crypto.randomUUID(),
  };

  db.pins.unshift(pin);
  await writeDb(db);

  return pin;
}

export async function updatePinLikes(id: string, delta: number): Promise<void> {
  const db = await readDb();
  const pin = db.pins.find(p => p.id === id);

  if (pin) {
    pin.likesCount = Math.max(0, (pin.likesCount || 0) + delta);
    await writeDb(db);
  }
}

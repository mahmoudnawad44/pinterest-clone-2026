import { getPins, searchPins, getPinsByTag } from '~/server/utils/pins';

export default cachedEventHandler(
  async (event) => {
    const { after, search, tag, category, limit = '21' } = getQuery(event);

    if (search) {
      return await searchPins(search, parseInt(limit));
    }

    if (tag) {
      return await getPinsByTag(tag, parseInt(limit), after);
    }

    return await getPins(parseInt(limit), after);
  },
  {
    maxAge: 60,
    swr: true,
    getKey: (event) => event.req.url,
  }
);

import { updatePinLikes } from '~/server/utils/pins';

export default defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { id, action } = body;

  if (!id || !['like', 'unlike'].includes(action)) {
    throw createError({ statusCode: 400, statusMessage: 'Invalid request' });
  }

  await updatePinLikes(id, action === 'like' ? 1 : -1);

  return { success: true };
});

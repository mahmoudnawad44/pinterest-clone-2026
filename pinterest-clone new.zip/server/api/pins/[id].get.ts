import { getPinById } from '~/server/utils/pins';

export default defineEventHandler(async (event) => {
  const id = getRouterParam(event, 'id');
  if (!id) throw createError({ statusCode: 400, statusMessage: 'ID required' });

  const pin = await getPinById(id);
  if (!pin) throw createError({ statusCode: 404, statusMessage: 'Pin not found' });

  return pin;
});

import { createPin } from '~/server/utils/pins';

export default defineEventHandler(async (event) => {
  const body = await readBody(event);

  const pin = await createPin({
    title: body.title,
    description: body.description,
    imageUrl: body.imageUrl,
    externalUrl: body.externalUrl,
    tags: body.tags || [],
    category: body.category,
    aspectRatio: body.aspectRatio || '3/4',
    likesCount: 0,
    savesCount: 0,
    createdAt: new Date().toISOString(),
  });

  return pin;
});

export default defineEventHandler(async () => {
  const { nodes } = await import('~/server/utils/pins').then(m => m.getPins(100));

  const baseUrl = 'https://your-domain.com';
  const urls = [
    `${baseUrl}/`,
    `${baseUrl}/categories`,
    `${baseUrl}/favorites`,
    ...nodes.map(pin => `${baseUrl}/pin/${pin.id}`),
  ];

  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.map(url => `  <url>
    <loc>${url}</loc>
    <changefreq>daily</changefreq>
    <priority>0.8</priority>
  </url>`).join('
')}
</urlset>`;

  setHeader(event, 'content-type', 'application/xml');
  return sitemap;
});

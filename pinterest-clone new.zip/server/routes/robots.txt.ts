export default defineEventHandler(() => {
  return `User-agent: *
Allow: /

Sitemap: /sitemap.xml`;
});

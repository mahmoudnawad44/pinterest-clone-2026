export default defineNuxtConfig({
  compatibilityDate: '2025-07-05',
  future: { compatibilityVersion: 4 },
  devtools: { enabled: true },
  modules: [
    '@nuxt/ui',
    '@nuxt/image',
    '@nuxtjs/i18n',
  ],

  runtimeConfig: {
    public: {
      version: '1.0.0',
    },
  },

  routeRules: {
    '/favorites': { swr: true },
    '/categories': { swr: true },
  },

  nitro: {
    prerender: {
      routes: ['/', '/sitemap.xml', '/robots.txt'],
    },
  },

  i18n: {
    locales: [
      { code: 'ar', name: 'العربية', file: 'ar-SA.json' },
    ],
    defaultLocale: 'ar',
    lazy: true,
    langDir: 'locales/',
    strategy: 'prefix_except_default',
  },

  image: {
    domains: ['*'],
  },

  app: {
    head: {
      htmlAttrs: { dir: 'rtl' },
    },
  },
});

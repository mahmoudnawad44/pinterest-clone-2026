const SAVES_STORAGE_KEY = 'pin_saves';

export interface SaveItem {
  id: string | number;
  savedAt: string;
  imageUrl: string;
  title: string;
}

export const useSaves = () => {
  const saves = useState<SaveItem[]>('saves', () => []);

  const persistSaves = () => {
    if (!process.client) return;
    localStorage.setItem(SAVES_STORAGE_KEY, JSON.stringify(saves.value));
  };

  const isSaved = (id) => {
    return saves.value.some(item => item.id === id);
  };

  const toggleSave = (pin) => {
    const exists = saves.value.some(item => item.id === pin.id);

    if (exists) {
      saves.value = saves.value.filter(item => item.id !== pin.id);
    } else {
      saves.value = [...saves.value, {
        id: pin.id,
        savedAt: new Date().toISOString(),
        imageUrl: pin.imageUrl,
        title: pin.title,
      }];
    }

    persistSaves();
  };

  const removeSave = (id) => {
    saves.value = saves.value.filter(item => item.id !== id);
    persistSaves();
  };

  onMounted(() => {
    if (!process.client) return;
    const raw = localStorage.getItem(SAVES_STORAGE_KEY);
    if (!raw) return;
    try {
      const parsed = JSON.parse(raw);
      saves.value = Array.isArray(parsed) ? parsed : [];
    } catch {
      saves.value = [];
    }
  });

  return {
    saves,
    isSaved,
    toggleSave,
    removeSave,
  };
};

const LIKES_STORAGE_KEY = 'pin_likes';

export interface LikeItem {
  id: string | number;
  likedAt: string;
}

export const useLikes = () => {
  const likes = useState<LikeItem[]>('likes', () => []);

  const persistLikes = () => {
    if (!process.client) return;
    localStorage.setItem(LIKES_STORAGE_KEY, JSON.stringify(likes.value));
  };

  const isLiked = (id) => {
    return likes.value.some(item => item.id === id);
  };

  const toggleLike = (pin) => {
    const exists = likes.value.some(item => item.id === pin.id);

    if (exists) {
      likes.value = likes.value.filter(item => item.id !== pin.id);
      $fetch('/api/pins/like', {
        method: 'POST',
        body: { id: pin.id, action: 'unlike' },
      }).catch(() => {});
    } else {
      likes.value = [...likes.value, { id: pin.id, likedAt: new Date().toISOString() }];
      $fetch('/api/pins/like', {
        method: 'POST',
        body: { id: pin.id, action: 'like' },
      }).catch(() => {});
    }

    persistLikes();
  };

  onMounted(() => {
    if (!process.client) return;
    const raw = localStorage.getItem(LIKES_STORAGE_KEY);
    if (!raw) return;
    try {
      const parsed = JSON.parse(raw);
      likes.value = Array.isArray(parsed) ? parsed : [];
    } catch {
      likes.value = [];
    }
  });

  return {
    likes,
    isLiked,
    toggleLike,
  };
};

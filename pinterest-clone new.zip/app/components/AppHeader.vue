<script setup>
const router = useRouter();
const route = useRoute();
const searchQuery = ref((route.query.q || '').toString());
const searchResults = ref([]);
const isLoading = ref(false);
const suggestionMenu = ref(false);
const onClickOutsideRef = ref(null);
const localePath = useLocalePath();

const search = () => {
  router.push({ path: localePath('/'), query: { ...route.query, q: searchQuery.value || undefined } });
  suggestionMenu.value = false;
};

async function fetch() {
  if (!searchQuery.value) {
    searchResults.value = [];
    return;
  }
  try {
    const response = await $fetch('/api/pins', {
      query: { search: searchQuery.value, limit: 6 },
    });
    searchResults.value = response.nodes || [];
  } finally {
    isLoading.value = false;
  }
}

const throttledFetch = useDebounceFn(async () => {
  await fetch();
}, 300);

watch(
  () => searchQuery.value,
  () => {
    isLoading.value = true;
    throttledFetch();
  }
);

const clearSearch = () => {
  suggestionMenu.value = false;
  searchQuery.value = '';
  router.push({ query: { ...route.query, q: undefined } });
};

onClickOutside(onClickOutsideRef, () => {
  suggestionMenu.value = false;
});
</script>

<template>
  <div class="flex w-full flex-row items-center px-3 lg:px-5 h-[72px] lg:h-20 z-40 fixed bg-white/85 dark:bg-black/85 backdrop-blur-sm dark:backdrop-blur-lg">
    <div class="flex flex-row w-full flex-nowrap items-center gap-2">
      <NuxtLink
        aria-label="Home"
        class="flex items-center justify-center min-w-[52px] min-h-[52px] hover:bg-black/5 hover:dark:bg-white/15 rounded-2xl transition active:scale-95"
        :to="localePath('/')">
        <img class="rounded-lg bg-[#e60023] w-8 h-8" src="/logo.svg" alt="Logo" loading="lazy" />
      </NuxtLink>
      <NuxtLink
        aria-label="Categories"
        exactActiveClass="bg-black dark:bg-white text-white dark:text-black"
        class="font-semibold cursor-pointer px-4 rounded-full hover:bg-black hover:dark:bg-white h-12 items-center justify-center hover:text-white hover:dark:text-black transition active:scale-95 lg:flex hidden"
        :to="localePath('/categories')">
        التصنيفات
      </NuxtLink>
      <NuxtLink
        aria-label="Favorites"
        exactActiveClass="bg-black dark:bg-white text-white dark:text-black"
        class="font-semibold cursor-pointer px-4 rounded-full hover:bg-black hover:dark:bg-white h-12 items-center justify-center hover:text-white hover:dark:text-black transition active:scale-95 lg:flex hidden"
        :to="localePath('/favorites')">
        المحفوظات
      </NuxtLink>
      <NuxtLink
        aria-label="Categories"
        exactActiveClass="!bg-black/10 dark:!bg-white/30"
        class="lg:hidden flex items-center justify-center min-w-12 min-h-12 rounded-full bg-black/5 dark:bg-white/15 hover:bg-black/10 hover:dark:bg-white/20 transition active:scale-95"
        :to="localePath('/categories')">
        <UIcon class="text-[#5f5f5f] dark:text-[#b7b7b7]" name="i-iconamoon-category-fill" size="26" />
      </NuxtLink>
      <NuxtLink
        aria-label="Favorites"
        exactActiveClass="!bg-black/10 dark:!bg-white/30"
        class="lg:hidden flex items-center justify-center min-w-12 min-h-12 rounded-full bg-black/5 dark:bg-white/15 hover:bg-black/10 hover:dark:bg-white/20 transition active:scale-95"
        :to="localePath('/favorites')">
        <UIcon class="text-[#5f5f5f] dark:text-[#b7b7b7]" name="i-iconamoon-heart-fill" size="26" />
      </NuxtLink>
      <div class="flex flex-shrink flex-grow flex-col text-sm font-semibold text-[#111] dark:text-[#eee]" ref="onClickOutsideRef">
        <div
          :class="[
            'flex h-12 flex-grow rounded-full pl-4 pr-3 transition-all hover:bg-black/10 hover:dark:bg-white/20',
            suggestionMenu ? 'bg-black/10 dark:bg-white/20' : 'bg-black/5 dark:bg-white/15',
          ]">
          <div @click="suggestionMenu = true" class="flex w-full items-center gap-4">
            <div v-if="!suggestionMenu" class="flex text-neutral-500 dark:text-neutral-400">
              <UIcon name="i-iconamoon-search-bold" size="20" />
            </div>
            <div class="flex w-full">
              <input
                class="w-full bg-transparent py-2 outline-none placeholder:text-[#757575] placeholder:dark:text-neutral-400"
                type="text"
                v-model="searchQuery"
                @keyup.enter="search"
                placeholder="البحث عن صور..." />
              <div v-if="searchQuery || suggestionMenu" class="flex items-center">
                <button
                  v-if="searchQuery"
                  @click="clearSearch"
                  class="flex items-center justify-center rounded-full w-8 h-8 hover:bg-black/10 hover:dark:bg-white/20 transition active:scale-95">
                  <UIcon name="i-iconamoon-close-bold" class="text-neutral-500 dark:text-neutral-400" size="20" />
                </button>
              </div>
            </div>
          </div>
        </div>
        <div
          v-if="suggestionMenu"
          class="absolute top-16 left-0 right-0 mx-3 lg:mx-5 rounded-[2rem] bg-white dark:bg-[#111] shadow-2xl border border-neutral-100 dark:border-neutral-800 overflow-hidden z-50">
          <div v-if="isLoading" class="p-5">
            <div class="flex flex-wrap justify-center gap-3">
              <div v-for="i in 6" :key="i" class="w-full sm:max-w-[300px] p-2">
                <div class="pb-[125%] relative overflow-hidden bg-neutral-200 dark:bg-neutral-800 skeleton rounded-[32px]"></div>
              </div>
            </div>
          </div>
          <div v-else-if="searchResults.length" class="p-3">
            <NuxtLink
              v-for="pin in searchResults"
              :key="pin.id"
              :to="localePath(`/pin/${pin.id}`)"
              @click="suggestionMenu = false"
              class="flex items-center gap-3 p-2 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-2xl transition">
              <NuxtImg :src="pin.imageUrl" class="w-12 h-12 rounded-xl object-cover" />
              <div class="flex-1">
                <div class="font-medium">{{ pin.title }}</div>
                <div class="text-xs text-neutral-500">{{ pin.tags?.join(', ') }}</div>
              </div>
            </NuxtLink>
          </div>
          <div v-else-if="searchQuery" class="p-5 text-center text-neutral-500">
            لا توجد نتائج
          </div>
        </div>
      </div>
      <NuxtLink
        :to="localePath('/add')"
        class="flex items-center justify-center min-w-[52px] min-h-[52px] bg-[#e60023] hover:bg-[#ad081b] text-white rounded-full transition active:scale-95">
        <UIcon name="i-iconamoon-sign-plus" size="24" />
      </NuxtLink>
    </div>
  </div>
</template>

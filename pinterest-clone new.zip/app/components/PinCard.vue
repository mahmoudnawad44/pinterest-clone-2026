<script setup>
defineProps({
  pin: {
    type: Object,
    required: true,
  },
});

const { toggleLike, isLiked } = useLikes();
const { toggleSave, isSaved } = useSaves();
const localePath = useLocalePath();
</script>

<template>
  <article class="break-inside-avoid mb-4">
    <div class="group relative rounded-2xl overflow-hidden bg-neutral-200 dark:bg-neutral-800">
      <NuxtLink :to="localePath(`/pin/${pin.id}`)">
        <NuxtImg
          :alt="pin.title"
          loading="lazy"
          :src="pin.imageUrl"
          class="w-full object-cover transition-transform duration-300 group-hover:scale-105"
          :style="{ aspectRatio: pin.aspectRatio || '3/4' }" />
      </NuxtLink>

      <div class="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-300">
        <button
          @click="toggleSave(pin)"
          :class="[
            'absolute top-3 right-3 px-4 py-2 rounded-full font-semibold text-sm transition-all active:scale-95',
            isSaved(pin.id) ? 'bg-black text-white' : 'bg-[#e60023] text-white opacity-0 group-hover:opacity-100',
          ]">
          {{ isSaved(pin.id) ? 'محفوظ' : 'حفظ' }}
        </button>

        <button
          @click="toggleLike(pin)"
          class="absolute bottom-3 left-3 w-10 h-10 rounded-full bg-white/90 dark:bg-black/90 flex items-center justify-center transition-all active:scale-95 opacity-0 group-hover:opacity-100">
          <UIcon
            :name="isLiked(pin.id) ? 'i-iconamoon-heart-fill' : 'i-iconamoon-heart'"
            :class="isLiked(pin.id) ? 'text-[#e60023]' : 'text-neutral-700 dark:text-neutral-300'"
            size="20" />
        </button>

        <a
          v-if="pin.externalUrl"
          :href="pin.externalUrl"
          target="_blank"
          rel="noopener noreferrer"
          class="absolute bottom-3 right-3 w-10 h-10 rounded-full bg-white/90 dark:bg-black/90 flex items-center justify-center transition-all active:scale-95 opacity-0 group-hover:opacity-100">
          <UIcon name="i-iconamoon-external-link" class="text-neutral-700 dark:text-neutral-300" size="20" />
        </a>
      </div>
    </div>

    <div class="pt-2 px-1">
      <h3 class="font-semibold text-sm line-clamp-2">{{ pin.title }}</h3>
      <p v-if="pin.description" class="text-xs text-neutral-500 dark:text-neutral-400 mt-1 line-clamp-2">
        {{ pin.description }}
      </p>

      <div v-if="pin.tags?.length" class="flex flex-wrap gap-1 mt-2">
        <NuxtLink
          v-for="tag in pin.tags.slice(0, 3)"
          :key="tag"
          :to="`/?tag=${encodeURIComponent(tag)}`"
          class="text-xs px-2 py-1 rounded-full bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-neutral-700 transition">
          #{{ tag }}
        </NuxtLink>
      </div>

      <div class="flex items-center gap-1 mt-2 text-xs text-neutral-500">
        <UIcon name="i-iconamoon-heart" size="14" />
        <span>{{ pin.likesCount || 0 }}</span>
      </div>
    </div>
  </article>
</template>

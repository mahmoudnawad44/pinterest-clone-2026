<script setup>
const { saves, removeSave } = useSaves();
const localePath = useLocalePath();

useSeoMeta({
  title: 'المحفوظات',
  robots: 'noindex, nofollow',
});
</script>

<template>
  <div class="px-3 lg:px-5">
    <h1 class="text-2xl font-bold mb-6 px-2">المحفوظات</h1>

    <div v-if="saves.length" class="columns-2 md:columns-3 lg:columns-4 gap-4">
      <div v-for="item in saves" :key="item.id" class="break-inside-avoid mb-4 relative group">
        <NuxtLink :to="localePath(`/pin/${item.id}`)">
          <NuxtImg
            :src="item.imageUrl"
            :alt="item.title"
            class="w-full rounded-2xl object-cover"
            loading="lazy" />
        </NuxtLink>

        <button
          @click="removeSave(item.id)"
          class="absolute top-2 right-2 w-10 h-10 rounded-full bg-black/50 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
          <UIcon name="i-iconamoon-close-bold" size="20" />
        </button>
      </div>
    </div>

    <div v-else class="flex flex-col items-center justify-center min-h-[50vh]">
      <UIcon name="i-iconamoon-heart" size="64" class="text-neutral-300 mb-4" />
      <p class="text-neutral-500 text-lg">لا توجد صور محفوظة</p>
      <NuxtLink :to="localePath('/')" class="mt-4 text-[#e60023] font-semibold hover:underline">
        اكتشف الصور
      </NuxtLink>
    </div>
  </div>
</template>

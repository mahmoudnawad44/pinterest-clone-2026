<script setup>
const { name } = useAppConfig().site;
const localePath = useLocalePath();

const categories = [
  { name: 'طبيعة', image: 'https://images.unsplash.com/photo-1501854140801-6d8dc242df3f?w=800', slug: 'nature' },
  { name: 'تصميم', image: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=800', slug: 'design' },
  { name: 'عمارة', image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800', slug: 'architecture' },
  { name: 'فن', image: 'https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=800', slug: 'art' },
  { name: 'طعام', image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800', slug: 'food' },
  { name: 'سفر', image: 'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=800', slug: 'travel' },
  { name: 'موضة', image: 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=800', slug: 'fashion' },
  { name: 'تصوير', image: 'https://images.unsplash.com/photo-1452587925148-ce544e77e70d?w=800', slug: 'photography' },
];

useSeoMeta({
  title: 'التصنيفات',
  description: `تصفح تصنيفات الصور على ${name}.`,
});
</script>

<template>
  <div class="flex flex-wrap justify-center max-w-screen-2xl m-auto">
    <NuxtLink v-for="category in categories" :key="category.slug" :to="localePath(`/?category=${encodeURIComponent(category.slug)}`)" class="w-full max-w-[444px] p-3 lg:p-2">
      <div class="pb-[75%] relative overflow-hidden">
        <NuxtImg
          :alt="category.name"
          class="object-cover absolute top-0 left-0 w-full h-full bg-neutral-200 dark:bg-neutral-800 rounded-[32px]"
          :src="category.image"
          loading="lazy"
          :title="category.name" />
        <div class="absolute left-0 right-0 top-0 bottom-0 bg-gradient-to-t hover:from-black/40 rounded-[32px] overflow-hidden">
          <div class="w-full h-full bg-gradient-to-t from-black/40 items-end py-6 px-5 flex">
            <div class="w-full text-center font-semibold text-3xl text-white">{{ category.name }}</div>
          </div>
        </div>
      </div>
    </NuxtLink>
  </div>
</template>

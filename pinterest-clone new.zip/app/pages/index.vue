<script setup>
const route = useRoute();
const { name } = useAppConfig().site;

const pinsData = ref([]);
const isLoading = ref(false);
const hasFetched = ref(false);
const tailEl = ref(null);
const pageInfo = ref({ hasNextPage: true, endCursor: null });

const variables = computed(() => ({
  search: route.query.q,
  tag: route.query.tag,
  category: route.query.category,
  after: pageInfo.value.endCursor,
}));

async function fetch() {
  if (isLoading.value || !pageInfo.value.hasNextPage) return;
  isLoading.value = true;

  try {
    const response = await $fetch('/api/pins', {
      query: variables.value,
    });
    pinsData.value.push(...response.nodes);
    pageInfo.value = response.pageInfo;
    hasFetched.value = true;
  } finally {
    isLoading.value = false;
  }
}

onMounted(fetch);

useIntervalFn(() => {
  if (!tailEl.value || isLoading.value) return;
  const { top } = tailEl.value.getBoundingClientRect();
  if (top - window.innerHeight < 400) {
    fetch();
  }
}, 500);

watch(
  () => route.query,
  () => {
    pinsData.value = [];
    pageInfo.value = { hasNextPage: true, endCursor: null };
    fetch();
  }
);

const pins = computed(() => pinsData.value);
const pinsEmpty = computed(() => hasFetched.value && !isLoading.value && pinsData.value.length === 0);

useHead(() => {
  const q = route.query.q;
  const tag = route.query.tag;
  let title = 'اكتشف الصور الملهمة';
  let description = `اكتشف وألهم وحفظ الصور المفضلة لديك على ${name}`;

  if (q) {
    title = `نتائج البحث عن "${q}"`;
    description = `نتائج البحث عن "${q}" على ${name}`;
  } else if (tag) {
    title = `صور #${tag}`;
    description = `تصفح صور #${tag} على ${name}`;
  }

  return {
    title,
    description,
    ogTitle: title,
    ogDescription: description,
  };
});
</script>

<template>
  <div class="px-3 lg:px-5">
    <!-- Tags Cloud -->
    <div class="flex gap-2 overflow-x-auto pb-4 mb-4 scrollbar-hide">
      <NuxtLink
        v-for="tag in ['طبيعة', 'تصميم', 'عمارة', 'فن', 'طعام', 'سفر', 'موضة', 'تصوير']"
        :key="tag"
        :to="`/?tag=${encodeURIComponent(tag)}`"
        :class="[
          'px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition',
          route.query.tag === tag 
            ? 'bg-black text-white dark:bg-white dark:text-black' 
            : 'bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700',
        ]">
        {{ tag }}
      </NuxtLink>
    </div>

    <!-- Masonry Grid -->
    <div class="columns-2 md:columns-3 lg:columns-4 gap-4">
      <PinCard v-for="pin in pins" :key="pin.id" :pin="pin" />
    </div>

    <!-- Loading -->
    <div v-if="isLoading" class="columns-2 md:columns-3 lg:columns-4 gap-4">
      <div v-for="i in 8" :key="i" class="break-inside-avoid mb-4">
        <div class="rounded-2xl bg-neutral-200 dark:bg-neutral-800 animate-pulse" style="aspect-ratio: 3/4;"></div>
        <div class="h-4 bg-neutral-200 dark:bg-neutral-800 rounded mt-2 w-3/4 animate-pulse"></div>
      </div>
    </div>

    <!-- Empty State -->
    <div v-if="pinsEmpty" class="flex flex-col items-center justify-center min-h-[50vh]">
      <UIcon name="i-iconamoon-search" size="64" class="text-neutral-300 mb-4" />
      <p class="text-neutral-500 text-lg">لا توجد نتائج</p>
    </div>

    <div ref="tailEl" class="h-10"></div>
  </div>
</template>

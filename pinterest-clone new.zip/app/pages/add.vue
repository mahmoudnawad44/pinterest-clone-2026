<script setup>
const router = useRouter();
const localePath = useLocalePath();

const form = reactive({
  title: '',
  description: '',
  imageUrl: '',
  externalUrl: '',
  tags: '',
  category: '',
});

const isSubmitting = ref(false);
const previewError = ref(false);

const handleSubmit = async () => {
  if (!form.imageUrl || !form.title) return;

  isSubmitting.value = true;
  try {
    const tags = form.tags.split(',').map(t => t.trim()).filter(Boolean);

    await $fetch('/api/pins', {
      method: 'POST',
      body: {
        ...form,
        tags,
        aspectRatio: await getImageAspectRatio(form.imageUrl),
      },
    });

    router.push(localePath('/'));
  } catch (error) {
    console.error(error);
  } finally {
    isSubmitting.value = false;
  }
};

const getImageAspectRatio = (url) => {
  return new Promise((resolve) => {
    if (process.server) { resolve('3/4'); return; }
    const img = new Image();
    img.onload = () => resolve(`${img.width}/${img.height}`);
    img.onerror = () => resolve('3/4');
    img.src = url;
  });
};

useSeoMeta({
  title: 'إضافة صورة جديدة',
});
</script>

<template>
  <div class="max-w-2xl mx-auto px-5 py-8">
    <h1 class="text-2xl font-bold mb-6">إضافة صورة جديدة</h1>

    <form @submit.prevent="handleSubmit" class="space-y-6">
      <div>
        <label class="block text-sm font-semibold mb-2">رابط الصورة *</label>
        <input
          v-model="form.imageUrl"
          type="url"
          required
          placeholder="https://example.com/image.jpg"
          class="w-full px-4 py-3 rounded-xl bg-neutral-100 dark:bg-neutral-800 border-0 focus:ring-2 focus:ring-[#e60023]" />

        <div v-if="form.imageUrl" class="mt-3 rounded-xl overflow-hidden bg-neutral-100 dark:bg-neutral-800">
          <NuxtImg
            :src="form.imageUrl"
            class="w-full max-h-96 object-contain"
            @error="previewError = true"
            @load="previewError = false" />
          <p v-if="previewError" class="p-4 text-red-500 text-center">فشل تحميل الصورة</p>
        </div>
      </div>

      <div>
        <label class="block text-sm font-semibold mb-2">العنوان *</label>
        <input
          v-model="form.title"
          type="text"
          required
          class="w-full px-4 py-3 rounded-xl bg-neutral-100 dark:bg-neutral-800 border-0 focus:ring-2 focus:ring-[#e60023]" />
      </div>

      <div>
        <label class="block text-sm font-semibold mb-2">الوصف</label>
        <textarea
          v-model="form.description"
          rows="3"
          class="w-full px-4 py-3 rounded-xl bg-neutral-100 dark:bg-neutral-800 border-0 focus:ring-2 focus:ring-[#e60023]"></textarea>
      </div>

      <div>
        <label class="block text-sm font-semibold mb-2">رابط المصدر (اختياري)</label>
        <input
          v-model="form.externalUrl"
          type="url"
          placeholder="https://example.com"
          class="w-full px-4 py-3 rounded-xl bg-neutral-100 dark:bg-neutral-800 border-0 focus:ring-2 focus:ring-[#e60023]" />
        <p class="text-xs text-neutral-500 mt-1">رابط الموقع المصدر للصورة</p>
      </div>

      <div>
        <label class="block text-sm font-semibold mb-2">التاجات</label>
        <input
          v-model="form.tags"
          type="text"
          placeholder="طبيعة, تصميم, سفر"
          class="w-full px-4 py-3 rounded-xl bg-neutral-100 dark:bg-neutral-800 border-0 focus:ring-2 focus:ring-[#e60023]" />
        <p class="text-xs text-neutral-500 mt-1">افصل بين التاجات بفاصلة</p>
      </div>

      <div>
        <label class="block text-sm font-semibold mb-2">التصنيف</label>
        <select
          v-model="form.category"
          class="w-full px-4 py-3 rounded-xl bg-neutral-100 dark:bg-neutral-800 border-0 focus:ring-2 focus:ring-[#e60023]">
          <option value="">اختر التصنيف</option>
          <option value="nature">طبيعة</option>
          <option value="design">تصميم</option>
          <option value="architecture">عمارة</option>
          <option value="art">فن</option>
          <option value="food">طعام</option>
          <option value="travel">سفر</option>
          <option value="fashion">موضة</option>
          <option value="photography">تصوير</option>
        </select>
      </div>

      <button
        type="submit"
        :disabled="isSubmitting || previewError"
        class="w-full py-3 bg-[#e60023] hover:bg-[#ad081b] text-white font-semibold rounded-full transition active:scale-95 disabled:opacity-50">
        {{ isSubmitting ? 'جاري النشر...' : 'نشر' }}
      </button>
    </form>
  </div>
</template>

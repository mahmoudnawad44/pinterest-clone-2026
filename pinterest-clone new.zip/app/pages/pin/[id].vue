<script setup>
const route = useRoute();
const { id } = route.params;
const localePath = useLocalePath();

const pin = ref(null);
const relatedPins = ref([]);

onMounted(async () => {
  try {
    const data = await $fetch(`/api/pins/${id}`);
    pin.value = data;

    if (data?.tags?.length) {
      const related = await $fetch('/api/pins', {
        query: { tag: data.tags[0], limit: 12 },
      });
      relatedPins.value = (related.nodes || []).filter(p => p.id !== id);
    }
  } catch (e) {
    console.error(e);
  }
});

const { toggleLike, isLiked } = useLikes();
const { toggleSave, isSaved } = useSaves();
</script>

<template>
  <div v-if="pin" class="max-w-6xl mx-auto px-5 py-8">
    <div class="bg-white dark:bg-neutral-900 rounded-[32px] shadow-lg overflow-hidden">
      <div class="flex flex-col lg:flex-row">
        <div class="lg:w-1/2 bg-neutral-100 dark:bg-neutral-800">
          <NuxtImg
            :src="pin.imageUrl"
            :alt="pin.title"
            class="w-full h-full object-contain max-h-[80vh]" />
        </div>

        <div class="lg:w-1/2 p-6 lg:p-10 flex flex-col">
          <div class="flex items-center justify-between mb-4">
            <div class="flex gap-2">
              <button
                @click="toggleSave(pin)"
                :class="[
                  'px-6 py-3 rounded-full font-semibold transition active:scale-95',
                  isSaved(pin.id) ? 'bg-black text-white' : 'bg-[#e60023] text-white hover:bg-[#ad081b]',
                ]">
                {{ isSaved(pin.id) ? 'محفوظ' : 'حفظ' }}
              </button>
            </div>

            <div class="flex gap-2">
              <button
                @click="toggleLike(pin)"
                class="w-12 h-12 rounded-full bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center hover:bg-neutral-200 transition">
                <UIcon
                  :name="isLiked(pin.id) ? 'i-iconamoon-heart-fill' : 'i-iconamoon-heart'"
                  :class="isLiked(pin.id) ? 'text-[#e60023]' : 'text-neutral-700'"
                  size="24" />
              </button>

              <a
                v-if="pin.externalUrl"
                :href="pin.externalUrl"
                target="_blank"
                class="w-12 h-12 rounded-full bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center hover:bg-neutral-200 transition">
                <UIcon name="i-iconamoon-external-link" size="24" />
              </a>
            </div>
          </div>

          <h1 class="text-2xl font-bold mb-2">{{ pin.title }}</h1>
          <p v-if="pin.description" class="text-neutral-600 dark:text-neutral-300 mb-4">
            {{ pin.description }}
          </p>

          <div v-if="pin.tags?.length" class="flex flex-wrap gap-2 mb-6">
            <NuxtLink
              v-for="tag in pin.tags"
              :key="tag"
              :to="`/?tag=${encodeURIComponent(tag)}`"
              class="px-3 py-1 rounded-full bg-neutral-100 dark:bg-neutral-800 text-sm hover:bg-neutral-200 transition">
              #{{ tag }}
            </NuxtLink>
          </div>

          <div class="flex items-center gap-4 text-sm text-neutral-500 mt-auto">
            <span>{{ pin.likesCount || 0 }} إعجاب</span>
            <span>{{ pin.savesCount || 0 }} حفظ</span>
            <span>{{ new Date(pin.createdAt).toLocaleDateString('ar-SA') }}</span>
          </div>
        </div>
      </div>
    </div>

    <div v-if="relatedPins.length" class="mt-12">
      <h2 class="text-xl font-bold mb-4">صور مشابهة</h2>
      <div class="columns-2 md:columns-3 lg:columns-4 gap-4">
        <PinCard v-for="p in relatedPins" :key="p.id" :pin="p" />
      </div>
    </div>
  </div>

  <div v-else class="flex items-center justify-center min-h-[50vh]">
    <div class="animate-spin w-8 h-8 border-4 border-[#e60023] border-t-transparent rounded-full"></div>
  </div>
</template>

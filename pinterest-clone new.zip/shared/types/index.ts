export interface Pin {
  id: string;
  title: string;
  description?: string;
  imageUrl: string;
  externalUrl?: string;
  tags: string[];
  category?: string;
  aspectRatio?: string;
  likesCount: number;
  savesCount: number;
  createdAt: string;
}

export interface LikeItem {
  id: string | number;
  likedAt: string;
}

export interface SaveItem {
  id: string | number;
  savedAt: string;
  imageUrl: string;
  title: string;
}
